function cof()
  print("cof")
end

for i = 1, 3 do
  cof()
end
