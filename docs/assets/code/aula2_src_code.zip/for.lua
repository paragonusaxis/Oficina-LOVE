for i = 1, 50 do
  print(i)
end
