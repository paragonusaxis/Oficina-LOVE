local x = 1 / 10
print(x)

print(string.format("%.50f", x))