require 'escopo5'
print(x)