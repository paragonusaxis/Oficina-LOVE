function cof(n)
  for i = 1, n do
    print("cof")
  end
end

cof(5)
