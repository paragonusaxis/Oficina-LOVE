local x = 9223372036854765808

while true do
  x = x + 1
  print(x)
end
