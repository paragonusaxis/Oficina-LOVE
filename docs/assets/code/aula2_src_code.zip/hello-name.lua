print("What's your name?")
local answer = io.read()
print("Hello, " .. answer .. "!")