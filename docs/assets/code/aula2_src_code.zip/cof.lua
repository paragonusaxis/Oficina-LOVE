print("cof")
print("cof")
print("cof")