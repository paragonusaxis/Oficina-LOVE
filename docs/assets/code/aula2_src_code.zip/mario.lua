-- imprimimos 4 interrogações no terminal
print("????")
