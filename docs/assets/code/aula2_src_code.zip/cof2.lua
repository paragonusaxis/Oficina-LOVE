for i = 1, 3 do
  print("cof")
end
