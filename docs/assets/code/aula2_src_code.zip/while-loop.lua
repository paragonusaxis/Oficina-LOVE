local i = 0
while 1 < 2 do
  print(i)
  i = i + 1
end

