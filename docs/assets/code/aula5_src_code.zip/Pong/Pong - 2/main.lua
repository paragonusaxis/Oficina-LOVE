--[[
    Puella Magi Pong Magica

    pong-2
    The ball is the one moving now!
]]

-- Requires utils.lua so that we can use its useful functions
require 'utils'

-- Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

-- The speed of our paddles
PADDLE_SPEED = 400

-- Called just once at the start of the game
function love.load()
    -- No filtering of pixels, without this our sprites will look blurry.
    love.graphics.setDefaultFilter('nearest', 'nearest')
    -- Sets some configurations
    love.window.setMode(WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = false,
        vsync = 1
    })

    -- Sets the title of our application window
    love.window.setTitle('Puella Magi Pong Magica')

    -- seed the RNG so that calls to random are always random
    math.randomseed(os.time())

    -- New fonts
    gothic_font = love.graphics.newFont("gothic-font.ttf", 54)
    rune_font = love.graphics.newFont("rune-font.ttf", 64)
    serif_font = love.graphics.newFont("serif-font.otf", 24)

    love.graphics.setFont(serif_font)

    -- Background
    -- credit: https://gekidan-inu-curry.tumblr.com/page/4
    background = love.graphics.newImage("background1.png")

    -- Sprites
    sprites = {
        madoka = love.graphics.newImage("paddle-madoka.png"),
        homura = love.graphics.newImage("paddle-homura.png"),
        ball = love.graphics.newImage("ball.png")        
    }

    -- Variables that will store our points
    player1_points = 0
    player2_points = 0

    -- Variables that will store our paddles' Y position
    player1_y = WINDOW_HEIGHT/2 - sprites.madoka:getHeight()/2
    player2_y = WINDOW_HEIGHT/2 - sprites.homura:getHeight()/2

    -- Variables that will store our ball's X and Y position
    ball_x = WINDOW_WIDTH/2 - sprites.ball:getWidth()/2
    ball_y = WINDOW_HEIGHT/2 - sprites.ball:getHeight()/2

    -- Speed of our ball
    ball_speed = 300

    -- Direction of our ball
    ball_direction = math.random(360)

    -- X and Y velocities of our ball
    ball_dx, ball_dy = velocity(ball_speed, ball_direction)

    -- Game state variable used control our game's different "moments"
    -- (used for beginning, menus, main game, high score list, etc.)
    -- we will use this to determine behavior during render and update
    game_state = 'start'
end

-- Called at every frame of our game, handles dt as argument
function love.update(dt)
    -- Player 1 movement
    if love.keyboard.isDown('w') then
        -- Add negative paddle speed to current Y scaled by deltaTime
        player1_y = math.max(player1_y + -PADDLE_SPEED * dt, 0)
    elseif love.keyboard.isDown('s') then
        -- Add positive paddle speed to current Y scaled by deltaTime
        player1_y = math.min(player1_y + PADDLE_SPEED * dt, WINDOW_HEIGHT - sprites.madoka:getHeight())
    end

    -- Player 2 movement
    if love.keyboard.isDown('up') then
        -- Add negative paddle speed to current Y scaled by deltaTime
        player2_y = math.max(player2_y + -PADDLE_SPEED * dt, 0)
    elseif love.keyboard.isDown('down') then
        -- Add positive paddle speed to current Y scaled by deltaTime
        player2_y = math.min(player2_y + PADDLE_SPEED * dt, WINDOW_HEIGHT - sprites.homura:getHeight())
    end

    -- Update our ball based on its speed and direction only if we're in play state;
    -- scale the velocity by dt so movement is framerate-independent
    if game_state == 'play' then
        ball_x = ball_x + ball_dx * dt
        ball_y = ball_y + ball_dy * dt
    end
end

-- Called whenever you press a key in your keyboard, passes the key as argument
function love.keypressed(key)
    -- Keys can be accessed by their name as a string
    if key == 'escape' then
        -- Terminates the game
        love.event.quit()
    -- If we press enter during the start state of the game, we'll go into play mode
    -- during play mode, the ball will move in a random direction
    elseif key == 'enter' or key == 'return' then
        if game_state == 'start' then
            game_state = 'play'
        else
            game_state = 'start'
            
            -- whenever we go back to start state, restart ball's position in the middle of the screen
            ball_x = WINDOW_WIDTH / 2 - sprites.ball:getWidth()/2
            ball_y = WINDOW_HEIGHT / 2 - sprites.ball:getHeight()/2

            -- get a new direction and update the velocities
            ball_direction = math.random(360)
            ball_dx, ball_dy = velocity(ball_speed, ball_direction)
        end
    end
end

-- Called after love.update, responsible for drawing things in the game's screen
function love.draw()
    -- Sets opacity to 50%
    love.graphics.setColor(1, 1, 1, 0.5)

    -- Draws the background
    love.graphics.draw(background)

    -- Sets opacity back to 100%
    love.graphics.setColor(1, 1, 1, 1)

    -- Draws some cryptic text in runic font
    love.graphics.setFont(rune_font)
    love.graphics.printf('Pong', 0, 20, WINDOW_WIDTH, 'center')

    -- Draws the points in gothic font
    love.graphics.setFont(gothic_font)
    love.graphics.printf(player1_points, 20, 20, WINDOW_WIDTH/2 - 100, 'left')
    love.graphics.printf(player2_points, WINDOW_WIDTH/2 + 100, 20, WINDOW_WIDTH/2 - 120, 'right')
    
    -- Returns to deafult font
    love.graphics.setFont(serif_font)

    -- Draws different things depending on the state of the game
    if game_state == 'start' then
        love.graphics.printf('start state', 0, 100, WINDOW_WIDTH, 'center')
    elseif game_state == 'play' then
        love.graphics.printf('play state', 0, 100, WINDOW_WIDTH, 'center')
    end

    -- Renders ball (center)
    love.graphics.draw(sprites.ball, ball_x, ball_y)

    -- Renders player 1's paddle (left side)
    love.graphics.draw(sprites.madoka, 20, player1_y)

    -- Renders player 2's paddle (right side)
    love.graphics.draw(sprites.homura, 
        WINDOW_WIDTH - 20 - sprites.homura:getWidth(), 
        player2_y
    )
end
