--[[
    Puella Magi Pong Magica

    pong-0
    Just drawing stuff in the screen c:
]]

-- Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

-- Called just once at the start of the game
function love.load()
    -- No filtering of pixels, without this our sprites will look blurry.
    love.graphics.setDefaultFilter('nearest', 'nearest')
    -- Sets some configurations
    love.window.setMode(WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = false,
        vsync = 1
    })

    -- Sets the title of our application window
    love.window.setTitle('Puella Magi Pong Magica')

    -- New fonts
    gothic_font = love.graphics.newFont("gothic-font.ttf", 54)
    rune_font = love.graphics.newFont("rune-font.ttf", 64)
    serif_font = love.graphics.newFont("serif-font.otf", 24)

    love.graphics.setFont(serif_font)

    -- Sprites
    sprites = {
        madoka = love.graphics.newImage("paddle-madoka.png"),
        homura = love.graphics.newImage("paddle-homura.png"),
        ball = love.graphics.newImage("ball.png")        
    }

    -- Background
    -- credit: https://gekidan-inu-curry.tumblr.com/page/4
    background = love.graphics.newImage("background1.png")
end

-- Called whenever you press a key in your keyboard, passes the key as argument
function love.keypressed(key)
    -- Keys can be accessed by their name as a string
    if key == 'escape' then
        -- Terminates the game
        love.event.quit()
    end
end

-- Called after love.update, responsible for drawing things in the game's screen
function love.draw()
    -- Sets opacity to 50%
    love.graphics.setColor(1, 1, 1, 0.5)

    -- Draws the background
    love.graphics.draw(background)

    -- Sets opacity back to 100%
    love.graphics.setColor(1, 1, 1, 1)

    -- Draws some cryptic text in runic font
    love.graphics.setFont(rune_font)
    love.graphics.printf('Pong', 0, 20, WINDOW_WIDTH, 'center')

    -- Draws the points in gothic font
    love.graphics.setFont(gothic_font)
    love.graphics.printf('0', 20, 20, WINDOW_WIDTH/2 - 100, 'left')
    love.graphics.printf('0', WINDOW_WIDTH/2 + 100, 20, WINDOW_WIDTH/2 - 120, 'right')
    
    -- Returns to deafult font
    love.graphics.setFont(serif_font)
	
    -- Renders ball (center)
    love.graphics.draw(sprites.ball, 
        WINDOW_WIDTH / 2 - sprites.ball:getWidth()/2, 
        WINDOW_HEIGHT / 2 - sprites.ball:getHeight()/2
    )

    -- Renders Madoka's paddle (left side)
    love.graphics.draw(sprites.madoka, 20, WINDOW_HEIGHT/2 - sprites.madoka:getHeight()/2)

    -- Renders Homura's paddle (right side)
    love.graphics.draw(sprites.homura, 
        WINDOW_WIDTH - 20 - sprites.homura:getWidth(), 
        WINDOW_HEIGHT/2 - sprites.homura:getHeight()/2
    )
end
