--[[
    Puella Magi Pong Magica

    pong-3
    INTRODUCING: CLASSES!!!! :D 
]]

-- class is a library that will allow us to modularize our game's code
-- in different components. This way we won't have to keep track
-- of many disparate variables and methods.
-- credit: https://github.com/vrld/hump/blob/master/class.lua
Class = require 'class'

-- Requires utils.lua so that we can use its useful functions
require 'utils'

-- Our Paddle class, that stores positions and dimensions for each paddle
require 'Paddle'

-- Our Ball class, same as our paddle class
require 'Ball'

-- Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

-- The speed of our paddles
PADDLE_SPEED = 400

-- Called just once at the start of the game
function love.load()
    -- No filtering of pixels, without this our sprites will look blurry.
    love.graphics.setDefaultFilter('nearest', 'nearest')
    -- Sets some configurations
    love.window.setMode(WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = false,
        vsync = 1
    })

    -- Sets the title of our application window
    love.window.setTitle('Puella Magi Pong Magica')

    -- seed the RNG so that calls to random are always random
    math.randomseed(os.time())

    -- New fonts
    gothic_font = love.graphics.newFont("gothic-font.ttf", 54)
    rune_font = love.graphics.newFont("rune-font.ttf", 64)
    serif_font = love.graphics.newFont("serif-font.otf", 24)

    love.graphics.setFont(serif_font)

    -- Background
    -- credit: https://gekidan-inu-curry.tumblr.com/page/4
    background = love.graphics.newImage("background1.png")

    -- Sprites
    sprites = {
        madoka = love.graphics.newImage("paddle-madoka.png"),
        homura = love.graphics.newImage("paddle-homura.png"),
        ball = love.graphics.newImage("ball.png")        
    }

    -- Variables that will store our points
    player1_points = 0
    player2_points = 0

    -- Initializes player1 and player2 as paddles
    player1 = Paddle(20, WINDOW_HEIGHT/2 - sprites.madoka:getHeight()/2, sprites.madoka)
    player2 = Paddle(WINDOW_WIDTH - 20 - sprites.homura:getWidth(), 
        WINDOW_HEIGHT/2 - sprites.homura:getHeight()/2, 
        sprites.homura
    )

    -- Initializes our ball
    ball = Ball()

    -- Game state variable used control our game's different "moments"
    -- (used for beginning, menus, main game, high score list, etc.)
    -- we will use this to determine behavior during render and update
    game_state = 'start'
end

-- Called at every frame of our game, handles dt as argument
function love.update(dt)
    -- Player 1 movement
    if love.keyboard.isDown('w') then
        -- changes player1's dy to negative
        player1.dy = -PADDLE_SPEED
    elseif love.keyboard.isDown('s') then
        -- Changes playery's dy to positive
        player1.dy = PADDLE_SPEED
    else
        player1.dy = 0
    end

    -- Player 2 movement
    if love.keyboard.isDown('up') then
        -- changes player1's dy to negative
        player2.dy = -PADDLE_SPEED
    elseif love.keyboard.isDown('down') then
         -- Changes playery's dy to positive
         player2.dy = PADDLE_SPEED
    else
        player2.dy = 0
    end

    -- Updates the paddles
    player1:update(dt)
    player2:update(dt)

    -- If we are in the play state, update our ball
    if game_state == 'play' then
        ball:update(dt)
    end
end

-- Called whenever you press a key in your keyboard, passes the key as argument
function love.keypressed(key)
    -- Keys can be accessed by their name as a string
    if key == 'escape' then
        -- Terminates the game
        love.event.quit()
    -- If we press enter during the start state of the game, we'll go into play mode
    -- during play mode, the ball will move in a random direction
    elseif key == 'enter' or key == 'return' then
        if game_state == 'start' then
            game_state = 'play'
        else
            game_state = 'start'
            
            -- whenever we go back to start state, reset the ball
            ball:reset()
        end
    end
end

-- Called after love.update, responsible for drawing things in the game's screen
function love.draw()
    -- Sets opacity to 50%
    love.graphics.setColor(1, 1, 1, 0.5)

    -- Draws the background
    love.graphics.draw(background)

    -- Sets opacity back to 100%
    love.graphics.setColor(1, 1, 1, 1)

    -- Draws some cryptic text in runic font
    love.graphics.setFont(rune_font)
    love.graphics.printf('Pong', 0, 20, WINDOW_WIDTH, 'center')

    -- Draws the points in gothic font
    love.graphics.setFont(gothic_font)
    love.graphics.printf(player1_points, 20, 20, WINDOW_WIDTH/2 - 100, 'left')
    love.graphics.printf(player2_points, WINDOW_WIDTH/2 + 100, 20, WINDOW_WIDTH/2 - 120, 'right')
    
    -- Returns to deafult font
    love.graphics.setFont(serif_font)

    -- Draws different things depending on the state of the game
    if game_state == 'start' then
        love.graphics.printf('start state', 0, 100, WINDOW_WIDTH, 'center')
    elseif game_state == 'play' then
        love.graphics.printf('play state', 0, 100, WINDOW_WIDTH, 'center')
    end

    -- Renders ball
    ball:render()

    -- Renders players's paddles
    player1:render()   
    player2:render()
end
