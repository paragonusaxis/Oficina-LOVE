--[[
    Puella Magi Pong Magica
    
    Constants -
    Some global constants for our game.
]]

-- size of our window
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

-- paddle movement speed
PADDLE_SPEED = 300